const Header = () => {
  return (
    <div className="boxShadow flex justify-between mb-7">
      <div className="font-bold">Fortune</div>
      <div>Persebaran Perumahan</div>
    </div>
  );
};
export default Header;
